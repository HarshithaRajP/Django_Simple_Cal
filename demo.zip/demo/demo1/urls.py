from django.urls import path
from.import views

urlpatterns =[

    path('',views.home,name='home'),
#resut.html filepath 
    path('add',views.add,name='add')
]