from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def home(request):
    #return HttpResponse("<h1>Hello world!</h1>")
    #return render(request,'homes.html')
    return render(request, 'homes.html',{'name':'sindhu'})

'''def add(request):
    val1 = int(request.GET['num1']) #accepting the values from the request
    val2 = int(request.GET['num2'])
    res = val1  + val2
    return render(request,'result.html',{'num1':val1, 'num2':val2,'result':res})'''


def add(request):
    
    val1 = int(request.POST['num1']) #accepting the values from the request
    val2 = int(request.POST['num2'])
    select = int(request.POST['option'])

    if select == 1:
        res = val1 + val2
    elif select == 2:
        res = val1 - val2
    elif select == 3:
        res = val1 * val2
    elif select == 4:
        res = val1 / val2
    elif select == 5:
        res = val1 ** val2
    elif select == 6:
        res = val1 % val2
    elif select == 7:
        res = val1 // val2
    else:
        res = 'invalid option'
    return render(request,'result.html',{'num1':val1,'num2':val2,'result':res})